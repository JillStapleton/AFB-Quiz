package com.example.android.afb_quiz;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    // Initializes the answersIncorrect variable.
    int answersIncorrect = 0;

    // Checks answers for question 1
    public int questionOne() {
        // q1Incorrect tracks whether any of the check boxes are incorrect
        int q1Incorrect = 0;

        //Finds the state of checkbox 1 and adds to q1Incorrect if the box is checked
        CheckBox question1Answer1 = (CheckBox) findViewById(R.id.question1_checkbox1);
        boolean q1a1 = question1Answer1.isChecked();
        if (q1a1 == true) {
            if (q1Incorrect < 1) {
                q1Incorrect += 1;
            }
        }

        //All of the following CheckBox sections find the state of the checkbox and
        // adds to q1Incorrect only if the answer is wrong and all previous answers were right
        CheckBox question1Answer2 = (CheckBox) findViewById(R.id.question1_checkbox2);
        boolean q1a2 = question1Answer2.isChecked();
        if (q1a2 == false) {
            if (q1Incorrect < 1) {
                q1Incorrect += 1;
            }
        }

        CheckBox question1Answer3 = (CheckBox) findViewById(R.id.question1_checkbox3);
        boolean q1a3 = question1Answer3.isChecked();
        if (q1a3 == false) {
            if (q1Incorrect < 1) {
                q1Incorrect += 1;
            }
        }

        CheckBox question1Answer4 = (CheckBox) findViewById(R.id.question1_checkbox4);
        boolean q1a4 = question1Answer4.isChecked();
        if (q1a4 == true) {
            if (q1Incorrect < 1) {
                q1Incorrect += 1;
            }
        }

        CheckBox question1Answer5 = (CheckBox) findViewById(R.id.question1_checkbox5);
        boolean q1a5 = question1Answer5.isChecked();
        if (q1a5 == true) {
            if (q1Incorrect < 1) {
                q1Incorrect += 1;
            }
        }

        CheckBox question1Answer6 = (CheckBox) findViewById(R.id.question1_checkbox6);
        boolean q1a6 = question1Answer6.isChecked();
        if (q1a6 == false) {
            if (q1Incorrect < 1) {
                q1Incorrect += 1;
            }
        }

        CheckBox question1Answer7 = (CheckBox) findViewById(R.id.question1_checkbox7);
        boolean q1a7 = question1Answer7.isChecked();
        if (q1a7 == true) {
            if (q1Incorrect < 1) {
                q1Incorrect += 1;
            }
        }

        CheckBox question1Answer8 = (CheckBox) findViewById(R.id.question1_checkbox8);
        boolean q1a8 = question1Answer8.isChecked();
        if (q1a8 == false) {
            if (q1Incorrect < 1) {
                q1Incorrect += 1;
            }
        }

        CheckBox question1Answer9 = (CheckBox) findViewById(R.id.question1_checkbox9);
        boolean q1a9 = question1Answer9.isChecked();
        if (q1a9 == false) {
            if (q1Incorrect < 1) {
                q1Incorrect += 1;
            }
        }

        //modifies the global variable answersIncorrect with the final result after checking all CheckBoxes in question 1
        answersIncorrect += q1Incorrect;
        return answersIncorrect;
    }

    public int questionTwo() {
        // q2Incorrect tracks whether the answer to question 2 is incorrect
        int q2Incorrect = 0;

        //Finds the state of the correct answer's radio button and adds to q2Incorrect if it is not selected
        RadioButton question2Answer = (RadioButton) findViewById(R.id.question2_radioButton1);
        boolean q2a = question2Answer.isChecked();
        if (q2a == false) {
            q2Incorrect += 1;
        }

        //modifies the global variable answersIncorrect after checking this question
        answersIncorrect += q2Incorrect;
        return answersIncorrect;
    }

    public int questionThree() {
        // tracks whether the answer to question 3 is incorrect
        int q3Incorrect = 0;

        //Finds the state of the correct answer's radio button and adds to q2Incorrect if it is not selected
        RadioButton question3Answer = (RadioButton) findViewById(R.id.question3_radioButton2);
        boolean q3a = question3Answer.isChecked();
        if (q3a == false) {
            q3Incorrect += 1;
        }

        //modifies the global variable answersIncorrect after checking this question
        answersIncorrect += q3Incorrect;
        return answersIncorrect;
    }

    public int questionFour() {
        // tracks whether the answer to question 4 is incorrect
        int q4Incorrect = 0;

        //finds user input for question 4 and changes it to a string
        EditText question4Answer = (EditText) findViewById(R.id.question4_EditText);
        String q4a = question4Answer.getText().toString();

        //compares user input sting and the correct answer from the strings file
        if (q4a.equals("R.string.hello")) {
            q4Incorrect += 0;
        } else {
            q4Incorrect += 1;
        }
        //modifies the global variable answersIncorrect after checking this question
        answersIncorrect += q4Incorrect;
        return answersIncorrect;
    }

    public int questionFive() {
        // tracks whether the answer to question 5 is incorrect
        int q5Incorrect = 0;

        //finds user input for question 5 and changes it to a string
        EditText question5Answer = (EditText) findViewById(R.id.question5_EditText);
        String q5a = question5Answer.getText().toString();

        //compares user input sting and the correct answer from the strings file
        if (q5a.equals("@string/hello")) {
            q5Incorrect += 0;
        } else {
            q5Incorrect += 1;
        }

        //modifies the global variable answersIncorrect after checking this question
        answersIncorrect += q5Incorrect;
        return answersIncorrect;
    }

    //Resets the answersIncorrect total to 0 after the results are shown when the check answers button is clicked
    public void resetAnswersIncorrect() {
        answersIncorrect = 0;
    }

    public void checkAnswers(View view) {
        // Calls the anwser checking methods for each question
        questionOne();
        questionTwo();
        questionThree();
        questionFour();
        questionFive();

        // Calculates the number of correct answers
        int answersCorrect = 5 - answersIncorrect;

        //Creates the toast message (the hardest part of this whole dang thing, and it's only one line!)
        Toast.makeText(MainActivity.this, "Pass!!!\nYou got " + answersCorrect + " answers correct and " + answersIncorrect + " answers incorrect.", Toast.LENGTH_LONG).show();

        //resets the answersIncorrect variable so the user can try again
        resetAnswersIncorrect();
    }


}


